# dralok

# Header
1. Home ->              /index
2. About ->             /about
3. Contact ->           /contact

--------------------------------

Book an Appointment     /book
Services                /services
Gallery                 /gallery
Feedback >              /feedback


--------------------------------

Blog                    /blog
Calendar                /calendar


--------------------------------

Privacy Policy          /privacy
Terms of Service        /terms
Disclaimer              /disclaimer

--------------------------------


4. Book an Appointment -> booking.htm

