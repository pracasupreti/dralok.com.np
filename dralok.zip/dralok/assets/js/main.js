  // Get the current year
  var currentYear = new Date().getFullYear();

  // Display it in the HTML element with id="current-year"
  document.getElementById("current-year").textContent = currentYear;